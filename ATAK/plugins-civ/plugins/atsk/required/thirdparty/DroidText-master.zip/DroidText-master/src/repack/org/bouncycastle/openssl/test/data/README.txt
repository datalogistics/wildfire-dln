Some OpenSSL-generated files, all containing the same DSA or RSA key,
with various types of encryption applied (as well as the unencrypted version).

The password used for all the encrypted files is "changeit".

The PKCS#8 files which contain ENCRYPTED PRIVATE KEY use this password for
the EncryptedPrivateKeyInfo object stored in them.

