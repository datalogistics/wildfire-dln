package repack.org.bouncycastle.jce.provider;

public class PKIXNameConstraintValidatorException
    extends Exception
{
    public PKIXNameConstraintValidatorException(String msg)
    {
        super(msg);
    }
}
