package repack.org.bouncycastle.cms;

public interface Recipient
{
}
