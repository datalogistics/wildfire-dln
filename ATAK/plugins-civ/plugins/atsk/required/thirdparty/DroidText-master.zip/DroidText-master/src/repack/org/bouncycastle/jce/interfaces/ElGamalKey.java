package repack.org.bouncycastle.jce.interfaces;

import repack.org.bouncycastle.jce.spec.ElGamalParameterSpec;

public interface ElGamalKey
{
    public ElGamalParameterSpec getParameters();
}
